package newweb;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class chkRemote 
{

	public static void main(String[] args) throws InterruptedException, MalformedURLException
	{
		
		// TODO Auto-generated method stub

		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setBrowserName("firefox");
		
		//capabilities.setCapability("firefox_binary", "C:/Users/npadmawa.CORP/AppData/Local/MozillaFirefox/firefox.exe");
		
		capabilities.setPlatform(Platform.ANY);
		//URL = IPAddress of registered node
		WebDriver driver = new RemoteWebDriver(new URL("http://10.220.56.41:4444/wd/hub"), capabilities);
		
		try
		{	
			//URl of file which you want to calls
			driver.get("file:///D:/160776_Manali/Advanced%20Selenium/WorkingWithForms.html");
			System.out.println(driver.getTitle());
			//driver.quit();	
		}
		
		catch(Exception e)
		{
			System.out.println("Hello!");
		}
		
	}

}
